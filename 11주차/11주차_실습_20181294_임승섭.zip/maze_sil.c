#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>

int main() {

    srand(time(NULL));

    FILE *fp = fopen("maze.maz", "w");

    int N, M; // N = WIDTH, M = HEIGHT
    scanf("%d", &N);
    scanf("%d", &M);

    // Dynamic Memory allocation for set, row_wall, column_wall
    int *set = (int *)malloc(sizeof(int) * N);
    int *row_wall = (int *)malloc(sizeof(int) * (N-1));
    int *column_wall = (int *)malloc(sizeof(int) * N);

    // initialize the set name
    for (int i = 0; i < N; i++)
        set[i] = i + 1;
    int room_number = N+1;

    // 맨 위 테두리 그림
    printf("+");
    fprintf(fp, "+");
    for (int i = 0; i < N; i++) {
        printf("-+");
        fprintf(fp, "-+");
    }
    printf("\n");
    fprintf(fp, "\n");
    
    // start
    int j;
    for (j = 0; j < M; j++) {
        
        // make every wall
        for (int i = 0; i < N; i++) {
            column_wall[i] = 1;
            if ( i < N-1)
                row_wall[i] = 1;
        }

        // erase the wall of row
        // 맨 왼쪽 테두리 그림
        printf("|");
        fprintf(fp, "|");

        for (int i = 0; i < N-1; i++) {

            if (set[i] != set[i+1]) {

                if (rand() % 2 == 1 || j== M-1) {
                    row_wall[i] = 0;
                    int target = set[i+1];
                    for (int k = 0; k < N; k++) {
                        if (set[k] == target)
                            set[k] = set[i];
                    }
                }
            }
            /*
            if (j < M-1 && set[i] != set[i+1]) { // two different adjacent room

                if (rand() % 2 == 1) { // 50% probability -> erase the wall
                    row_wall[i] = 0; // erase the wall between set[i] and set[i+1]
                    int target = set[i+1];
                    for (int k = i+1; k < N; k++) {  // change the set name to 'set[i]' for every 'set[i+1]'
                        if (set[k] == target)
                            set[k] = set[i];
                    }
                }
            }

            // 맨 밑에 있는 줄일 경우, 방 이름 다르면 다 뚫어
            if (j == M-1 && set[i] != set[i+1]) {
                row_wall[i] = 0;
                int target = set[i+1];
                for (int k = i+1; k < N; k++) {
                    if (set[k] == target)
                        set[k] = set[i];
                }
            }*/


            // 방과 방 사이의 벽 그림
            if (row_wall[i] == 0) {
                printf("  ");
                fprintf(fp, "  ");
            }
            else if (row_wall[i] == 1) {
                printf(" |");
                fprintf(fp, " |");
            }
        }
                    
        // 맨 오른쪽 테두리 그림
        printf(" |\n");
        fprintf(fp, " |\n");


        // erase the wall of column
        int flag = 0;

        // 맨 왼쪽 테두리 그림
        if (j < M-1) {
            printf("+");
            fprintf(fp, "+");
        }

        // for i = 0; 첫번째 방일 때
        // 만약 두 번째 방과 연결되지 않았으면 무조건 벽을 뚫어야 함
        if(set[0] != set[1]) {
            column_wall[0] = set[0];
            flag = 1;
        }
        // 같다면 랜덤으로 뚫어주고, flag로 그 상태를 알려준다.
        else {    
            if (rand()%2 == 1) {
                column_wall[0] = set[0];
                flag = 1;
            }
            else {
                column_wall[0] = ++room_number;
                flag = 0;
            }
        }

        // 첫 번째 방의 아래 벽 그림
        if (j < M-1) {
            if (flag == 0) {
                printf("-+");
                fprintf(fp, "-+");
            }
            else {
                printf(" +");
                fprintf(fp, " +");
            }
        }


        // for i > 0; 두 번째 방부터
        for (int i = 1; i < N; i++) {

            // 이전 방과 연결되어 있을 때
            if (set[i] == set[i-1]) {
                // 이전 방에서 이미 뚫었다면 여기서 뚫 수 없다. 안뚫었으니까 flag = 0
                if (flag == 1) {
                    column_wall[i] = ++room_number;
                    flag = 0;
                }
                // 이전 방이 뚫려있지 않으면 랜덤으로 뚫어주고 flag로 그 상태를 알려준다
                else if (flag == 0) {
                    if (rand()%2 == 1) {
                        column_wall[i] = set[i];
                        flag = 1;
                    }
                    else {
                        column_wall[i] = ++room_number;
                        flag = 0;
                    }
                }
            }

            // 이전 방과 연결되어 있지 않을 때. flag와 상관 없음.
            else {
                // 랜덤으로 뚫어주고 flag로 상태 알려준다
                if (rand()%2 == 1) {
                    column_wall[i] = set[i];
                    flag = 1;
                }
                else {
                    column_wall[i] = ++room_number;
                    flag = 0;
                }
            }

            // 혹시 다음 방과는 연결되지 않은 연결된 방들의 마지막인데 아직 안뚫었다면 뚫어준다
            if (set[i] != set[i+1]) {
                int flag2 = 0; // 혹시 모두 뚫리지 않았으면 0, 하나라도 뚫려있으면 1
                int target = set[i];
                for (int k = 0; k < i; k++) {
                    if (set[k] == target) {
                        if (column_wall[k] == set[k])
                            flag2 = 1;
                    }
                }

                if (flag2 == 0) {
                    column_wall[i] = set[i];
                    flag = 1;
                }
            }



            // 각 방의 아래 벽 그림
            if (j < M-1) {
                if (flag == 0) {
                    printf("-+");
                    fprintf(fp, "-+");
                }
                else {
                    printf(" +");
                    fprintf(fp, " +");
                }
            }
        }

        // 줄넘김
        if (j < M-1) {
            printf("\n");
            fprintf(fp, "\n");
        }

        // set[]을 column_wall[]로 업데이트
        for (int i = 0; i < N; i++)
            set[i] = column_wall[i];
    }

    // 맨 아래 테두리 그림
    printf("+");
    fprintf(fp, "+");
    for (int i = 0; i < N; i++) {
        printf("-+");
        fprintf(fp, "-+");
    }
}