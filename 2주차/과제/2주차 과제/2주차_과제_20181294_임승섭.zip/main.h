#include <stdio.h>
#include <stdlib.h>


void cal_func(int, int*);
void pnt_func(int**, int);