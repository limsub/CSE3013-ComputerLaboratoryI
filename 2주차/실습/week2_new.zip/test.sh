#!/bin/bash

echo "difference between ans1.txt and myans1.txt: "
diff ans1.txt myans1.txt
echo "difference between ans2.txt and myans2.txt: "
diff ans2.txt myans2.txt
echo "difference between ans3.txt and myans3.txt: "
diff ans3.txt myans3.txt
